<template>
    <left-side>leftSidemenui</left-side>
</template>


<script>
import LeftSide from "../../slots/LeftSide.vue"
export default {
    components:{LeftSide}
}
</script>