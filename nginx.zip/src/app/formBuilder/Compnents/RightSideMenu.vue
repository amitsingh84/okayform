<template>
    <div class="row g-0">
          <div class="" style="background-color:var(--tertiary-color)">
             dsdfdfssdfdf
          </div>
          
        </div>
</template>


<script>
// import Maincontent from "./Compnents/Maincontent.vue";
export default {
    // components:{Maincontent}
}
</script>