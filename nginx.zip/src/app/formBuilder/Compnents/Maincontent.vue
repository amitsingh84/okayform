<template>
    <div class="mian_content_conatiner">Maincontendf</div>
</template>


<script>
export default {
    
}
</script>