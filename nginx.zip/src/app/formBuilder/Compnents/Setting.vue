<template>
    <div>setting</div>
</template>
<script>
export default {
    
}
</script>