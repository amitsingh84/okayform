// import { HttpBaseService } from '../../shared/services/index';
// import { apiConstants } from '../index';

// const forgotPassword = (body) => {
//   const url = apiConstants.forgotPassword
//   return HttpBaseService.processRequest(url, HttpBaseService.POST, null, null, body);
// }

// const verifyUserToken = (body) => {
//   const url = apiConstants.verifyUserToken
//   return HttpBaseService.processRequest(url, HttpBaseService.POST, null, null, body);
// }
// const login = (body) => {
//   const url = apiConstants.login;
//   return HttpBaseService.processRequest(url, HttpBaseService.POST, null, null, body);
// };
// const activateUser = (body) => {
//   const url = apiConstants.activateUser
//   return HttpBaseService.processRequest(url, HttpBaseService.POST, null, null, body);
// }

// /*-----testing-----------*/
// const testUser = (body) => {
//   const url = apiConstants.testUser
//   return HttpBaseService.processRequest(url, HttpBaseService.POST, null, null, body);
// }

// export default { login, verifyUserToken, activateUser, forgotPassword,testUser };
