<template>
    <router-view></router-view>
</template>


<script>
export default {
//     created(){
//     if(!this.$store.getters.isAuthenticated){
//       this.$router.push('/auth');
//     }
//     // console.log(this.$store.getters.isAuthenticated)
//     // console.log(this.$store.getters.getClaims)
//   }
}
</script>