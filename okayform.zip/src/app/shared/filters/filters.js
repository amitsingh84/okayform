export default {
  filters: {},
  methods: {
    $checkRBACAccess() {
      //Write Filters Here
    },
  },
};
