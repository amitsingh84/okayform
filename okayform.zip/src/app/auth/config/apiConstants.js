export const apiConstants = {
  login: "/api/Account/authenticate",
  verifyUserToken : "/api/account/isvalidInvitation",
  activateUser : "/api/account/activateInvitedEmployee",
  forgotPassword : "/api/account/forgotPassword",
  testUser:"/api/User"
};
