// import UserLogin from './views/UserLogin';
// import Login from './views/Login.vue';
// import ChangePassword from './views/ChangePassword.vue';
// const authRoutes = [
//   { path: '/', component: UserLogin},
//   {
//     path: '/auth',
//     component: () => import("./AppAuth.vue"),
//     children: [
//       {
//         path: '',
//         name: 'login',
//         component: Login
//       },
//       {
//         path: 'changepassword',
//         name: 'changepassword',
//         component: ChangePassword
//       },
      
//     ]
//   }
// ];

// export default authRoutes;
