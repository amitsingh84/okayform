import { createApp } from 'vue'
import App from '../src/app/App.vue'
import router from './app/router/index' 
createApp(App).use(router).mount('#app')
